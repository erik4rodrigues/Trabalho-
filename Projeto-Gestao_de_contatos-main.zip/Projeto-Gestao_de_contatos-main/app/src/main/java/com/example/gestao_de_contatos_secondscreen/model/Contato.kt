package com.example.gestao_de_contatos_secondscreen.model

data class Contato(
    val id:Long? = null,
    val nome:String,
    val sobrenome:String,
    val numero:Int
)
