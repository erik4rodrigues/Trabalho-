package com.example.gestao_de_contatos_secondscreen.model

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class ContatoDAO(context:Context) : SQLiteOpenHelper(context, db_name,null,db_version) {
    companion object {
        private val db_name = "contatos.db"
        private val db_version = 1

    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS contatos (id INTEGER PRIMARY KEY AUTOINCREMENT,nome TEXT,sobrenome TEXT,numero integer)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (newVersion > oldVersion) {
            db.execSQL("DROP TABLE contatos")
            onCreate(db)
        }

    }

   }

