package com.example.gestao_de_contatos_secondscreen

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toolbar
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class gestao_de_contatos_third_screen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_gestao_de_contatos_third_screen)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    val toolbar = findViewById<Toolbar>(R.id.activity_main_toolbar2)
    val backarrow2 = findViewById<ImageView>(R.id.activity_main_backarrow2)
    val mainicon = findViewById<ImageView>(R.id.activity_main_icon)
    val gabrieltrindade = findViewById<TextView>(R.id.activity_main_Gabriel_Trindade)
    val containercomponents2 = findViewById<View>(R.id.actvity_main_ContainerComponents2)
    val editname = findViewById<EditText>(R.id.activity_main_edit_number)
    val button2 = findViewById<Button>(R.id.activity_main_bt1)

     button2.setOnClickListener{
           openNextActivity()
     }

    }
  private fun openNextActivity(){
   val intent = Intent(this, gestao_de_contatos_fourth_screen::class.java)
      startActivity(intent)
  }
}