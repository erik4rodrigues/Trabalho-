package com.example.gestao_de_contatos_secondscreen

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toolbar
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        try {


            val Contatos = ""
            val bancoDados = openOrCreateDatabase(Contatos, MODE_PRIVATE,null)

             bancoDados.execSQL("CREATE TABLE IF NOT EXISTS Contatos(nome VARCHAR,sobrenome VARCHAR, numeros INT(9))")

             bancoDados.execSQL("INSERT INTO Contatos(nome,sobrenome,numero) VALUES(Gabriel,Trindade,55519890029)")

            val consulta = "SELECT nome,sobrenome,telefone FROM Contatos"

            val cursor = bancoDados.rawQuery(consulta,null)

            val indiceNome= cursor.getColumnIndex("nome")
            val indiceSobrenome = cursor.getColumnIndex("sobrenome")
            val indiceNumero = cursor.getColumnIndex("numero")
            cursor.moveToFirst()

            while (cursor != null){
                val nome = cursor.getString(indiceNome)
                val sobrenome = cursor.getString(indiceSobrenome)
                val numero = cursor.getString(indiceNumero)
                Log.i("RESULTADO", "/nome: $nome/ sobrenome: $sobrenome/ numero:  $numero")
                cursor.moveToNext()

            }

        }catch (e: Exception){
            e.printStackTrace()

        }




        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val toolbar = findViewById<Toolbar>(R.id.activity_main_toolbar)
        val imageview = findViewById<ImageView>(R.id.activity_main_backarrow)
        val icon = findViewById<ImageView>(R.id.activity_main_icon)
        val adicionarfoto = findViewById<TextView>(R.id.activity_main_adicionar_foto)
        val containercomponents = findViewById<View>(R.id.actvity_main_ContainerComponents)
        val editname = findViewById<EditText>(R.id.activity_main_edit_name)
        val editsobrenome = findViewById<EditText>(R.id.activity_main_edit_sobrenome)
        val editnumber = findViewById<EditText>(R.id.activity_main_edit_numero)
        val botaoadicionar = findViewById<Button>(R.id.activity_main_botao_adicionar)

        botaoadicionar.setOnClickListener{
            openNextActivity()












        }

            }





    private fun openNextActivity(){
      val intent  = Intent(this, gestao_de_contatos_third_screen::class.java)
        startActivity(intent)
    }
}









