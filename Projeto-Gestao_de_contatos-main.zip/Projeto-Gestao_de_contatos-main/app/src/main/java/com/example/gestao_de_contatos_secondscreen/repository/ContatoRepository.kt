package com.example.gestao_de_contatos_secondscreen.repository

import android.content.ContentValues
import android.content.Context
import com.example.gestao_de_contatos_secondscreen.model.Contato
import com.example.gestao_de_contatos_secondscreen.model.ContatoDAO

class ContatoRepository(private val context:Context) {
    companion object{
        private val TABLE = "contatos"
    }
    private val db = ContatoDAO(context).writableDatabase


    fun insert(contato: Contato): Long {
        val contentValues = ContentValues().apply {
            put("nome",contato.nome)
            put("sobrenome", contato.sobrenome)
            put("numero", contato.numero)
        }
       return db.insert(TABLE,null,contentValues)
    }
    fun update(contato:Contato): Int {
        val contentValues = ContentValues().apply {
           put("nome", contato.nome)
            put("sobrenome", contato.sobrenome)
            put("numero", contato.numero)
        }
     return db.update(TABLE, contentValues, "id = ?", arrayOf(contato.id.toString()))
    }
}