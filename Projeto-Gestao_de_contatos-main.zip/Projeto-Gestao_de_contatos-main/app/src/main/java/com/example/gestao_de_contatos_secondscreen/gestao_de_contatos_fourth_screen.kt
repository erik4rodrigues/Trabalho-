package com.example.gestao_de_contatos_secondscreen

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toolbar
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.snackbar.Snackbar

class gestao_de_contatos_fourth_screen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_gestao_de_contatos_fourth_screen)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
           val toolbar = findViewById<Toolbar>(R.id.activity_main_toolbar3)
           val imageview = findViewById<ImageView>(R.id.activity_main_back_icon)
           val icon = findViewById<ImageView>(R.id.activity_main_icon)
           val editphoto = findViewById<TextView>(R.id.activity_main_edit_photo)
           val containeircomponents = findViewById<View>(R.id.actvity_main_ContainerComponents)
           val editname = findViewById<EditText>(R.id.activity_main_edit_name)
           val editsobrenome = findViewById<EditText>(R.id.activity_main_edit_sobrenome)
           val editnumber = findViewById<EditText>(R.id.activity_main_edit_numero)
           val botaosalvar = findViewById<Button>(R.id.activity_main_botao_salvar)

        botaosalvar.setOnClickListener{
           showSnackShort()


        }

        }
    private fun showSnackShort() {
        Snackbar.make(findViewById(android.R.id.content), R.string.Save_successful, Snackbar.LENGTH_SHORT).show()
    }
}
